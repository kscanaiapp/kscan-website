const features = [
  {
    title: "Real-world recognition",
    body: "The demo starts from physical inspiration, not a search bar, so the product promise is obvious immediately.",
  },
  {
    title: "Fashion-specific parsing",
    body: "K Scan reads silhouette, texture, color, and styling cues instead of collapsing everything into a generic product guess.",
  },
  {
    title: "Retailer-neutral conversion",
    body: "The flow is structured around comparison and checkout readiness, not closed-loop inventory or generic discovery.",
  },
];

export function DemoFeatures() {
  return (
    <div>
      <div className="mb-8">
        <p className="text-[11px] font-semibold uppercase tracking-[0.26em] text-[#6D28D9]">
          Why it matters
        </p>
        <h2 className="mt-2 font-serif text-3xl text-[#0A0A0A] md:text-5xl">
          Vogue meets computer vision.
        </h2>
      </div>

      <div className="grid gap-5 md:grid-cols-3">
        {features.map((feature) => (
          <div
            key={feature.title}
            className="rounded-[1.75rem] border border-black/8 bg-white p-6 shadow-[0_10px_30px_rgba(10,10,10,0.05)]"
          >
            <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-[#6D28D9]">
              K Scan
            </p>
            <h3 className="mt-3 text-xl font-medium text-[#0A0A0A]">
              {feature.title}
            </h3>
            <p className="mt-3 text-sm leading-6 text-[#737373]">
              {feature.body}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}
