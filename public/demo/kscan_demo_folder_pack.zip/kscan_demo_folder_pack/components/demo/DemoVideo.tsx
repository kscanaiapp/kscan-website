type DemoVideoProps = {
  videoSrc: string;
  posterSrc?: string;
  caption?: string;
};

export function DemoVideo({ videoSrc, posterSrc, caption }: DemoVideoProps) {
  return (
    <div>
      <div className="mb-5 flex items-end justify-between gap-4">
        <div>
          <p className="text-[11px] font-semibold uppercase tracking-[0.26em] text-[#6D28D9]">
            Live Demo
          </p>
          <h2 className="mt-2 font-serif text-3xl text-[#0A0A0A] md:text-5xl">
            Current product walkthrough
          </h2>
        </div>
      </div>

      <div className="overflow-hidden rounded-[2rem] border border-black/8 bg-black shadow-[0_28px_80px_rgba(10,10,10,0.14)]">
        <video
          src={videoSrc}
          poster={posterSrc}
          autoPlay
          muted
          loop
          playsInline
          controls
          preload="auto"
          className="block h-auto w-full object-cover"
        />
      </div>

      {caption ? (
        <p className="mt-4 max-w-3xl text-sm leading-6 text-[#737373] md:text-base">
          {caption}
        </p>
      ) : null}
    </div>
  );
}
