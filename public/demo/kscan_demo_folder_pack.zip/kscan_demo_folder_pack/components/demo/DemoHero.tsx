import Link from "next/link";

export function DemoHero() {
  return (
    <section className="bg-white">
      <div className="mx-auto grid max-w-7xl gap-10 px-6 py-16 md:px-8 md:py-24 lg:grid-cols-[1.15fr_0.85fr] lg:items-end">
        <div>
          <p className="mb-4 text-[11px] font-semibold uppercase tracking-[0.26em] text-[#6D28D9]">
            Product Demo
          </p>

          <h1 className="max-w-4xl font-serif text-5xl leading-[0.96] text-[#0A0A0A] md:text-7xl">
            See it. Say it. Get it.
          </h1>

          <p className="mt-6 max-w-2xl text-base leading-7 text-[#737373] md:text-lg">
            K Scan turns a real-world look into a structured fashion signal,
            retailer-aware options, and a clean path to checkout.
          </p>

          <div className="mt-8 flex flex-wrap gap-3">
            <Link
              href="/"
              className="inline-flex items-center justify-center rounded-full bg-[#6D28D9] px-6 py-3 text-sm font-medium uppercase tracking-[0.18em] text-white shadow-[0_16px_40px_rgba(109,40,217,0.22)] transition hover:opacity-95"
            >
              Join Waitlist
            </Link>

            <Link
              href="/investors"
              className="inline-flex items-center justify-center rounded-full border border-black/10 bg-white px-6 py-3 text-sm font-medium uppercase tracking-[0.18em] text-[#0A0A0A] transition hover:bg-[#F5F5F5]"
            >
              Investor Access
            </Link>
          </div>
        </div>

        <div className="rounded-[2rem] border border-black/8 bg-[rgba(255,255,255,0.8)] p-6 shadow-[0_20px_60px_rgba(10,10,10,0.08)] backdrop-blur-md">
          <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-[#6D28D9]">
            Digital Concierge
          </p>

          <div className="mt-4 space-y-4">
            <div className="rounded-[1.5rem] border border-black/8 bg-white p-4">
              <p className="text-xs font-semibold uppercase tracking-[0.22em] text-[#737373]">
                The moment
              </p>
              <p className="mt-2 text-lg font-medium text-[#0A0A0A]">
                Spot a look in the wild
              </p>
            </div>

            <div className="rounded-[1.5rem] border border-black/8 bg-white p-4">
              <p className="text-xs font-semibold uppercase tracking-[0.22em] text-[#737373]">
                Style-Parse
              </p>
              <p className="mt-2 text-lg font-medium text-[#0A0A0A]">
                Break it into silhouette, texture, color, and category
              </p>
            </div>

            <div className="rounded-[1.5rem] border border-black/8 bg-white p-4">
              <p className="text-xs font-semibold uppercase tracking-[0.22em] text-[#737373]">
                Commerce
              </p>
              <p className="mt-2 text-lg font-medium text-[#0A0A0A]">
                Compare options and move to checkout instantly
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
