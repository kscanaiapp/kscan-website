import Image from "next/image";

type GalleryItem = {
  src: string;
  title: string;
  description: string;
  tag: string;
};

type DemoGalleryProps = {
  items: GalleryItem[];
};

export function DemoGallery({ items }: DemoGalleryProps) {
  return (
    <div>
      <div className="mb-8">
        <p className="text-[11px] font-semibold uppercase tracking-[0.26em] text-[#6D28D9]">
          Demo Stills
        </p>
        <h2 className="mt-2 font-serif text-3xl text-[#0A0A0A] md:text-5xl">
          Additional product moments
        </h2>
        <p className="mt-4 max-w-2xl text-base leading-7 text-[#737373]">
          Use these stills as supporting proof points across desktop, tablet, and mobile layouts.
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
        {items.map((item) => (
          <article
            key={item.title}
            className="overflow-hidden rounded-[1.75rem] border border-black/8 bg-white shadow-[0_14px_40px_rgba(10,10,10,0.06)]"
          >
            <div className="relative aspect-[4/5] bg-[#F5F5F5]">
              <Image
                src={item.src}
                alt={item.title}
                fill
                className="object-cover"
                sizes="(max-width: 768px) 100vw, (max-width: 1280px) 50vw, 33vw"
              />
            </div>

            <div className="p-5">
              <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-[#6D28D9]">
                {item.tag}
              </p>
              <h3 className="mt-2 text-xl font-medium text-[#0A0A0A]">
                {item.title}
              </h3>
              <p className="mt-3 text-sm leading-6 text-[#737373]">
                {item.description}
              </p>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}
