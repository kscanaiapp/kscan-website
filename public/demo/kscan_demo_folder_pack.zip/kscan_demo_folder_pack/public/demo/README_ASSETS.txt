Put your current demo assets in this folder with these exact names:

kscan-demo.mp4
kscan-demo-poster.jpg
scene-style-parse.jpg
scene-ar-buy.jpg
scene-checkout.jpg

Suggested mapping:
- kscan-demo.mp4 -> your current demo video
- kscan-demo-poster.jpg -> poster frame for the video
- scene-style-parse.jpg -> still focused on Style-Parse
- scene-ar-buy.jpg -> the AI-generated POV image you liked
- scene-checkout.jpg -> future checkout or confirmation still
