import { DemoHero } from "@/components/demo/DemoHero";
import { DemoVideo } from "@/components/demo/DemoVideo";
import { DemoGallery } from "@/components/demo/DemoGallery";
import { DemoFeatures } from "@/components/demo/DemoFeatures";
import { demoContent } from "@/lib/demo-content";

export const metadata = {
  title: "Demo | K Scan AI",
  description:
    "See how K Scan turns visual inspiration into a fast path to purchase.",
};

export default function DemoPage() {
  return (
    <main className="min-h-screen bg-white text-[#0A0A0A]">
      <DemoHero />
      <section className="border-t border-black/5 bg-[#FAFAFA]">
        <div className="mx-auto max-w-7xl px-6 py-10 md:px-8 md:py-14">
          <DemoVideo
            videoSrc={demoContent.video.src}
            posterSrc={demoContent.video.poster}
            caption={demoContent.video.caption}
          />
        </div>
      </section>

      <section className="border-t border-black/5 bg-white">
        <div className="mx-auto max-w-7xl px-6 py-14 md:px-8 md:py-20">
          <DemoFeatures />
        </div>
      </section>

      <section className="border-t border-black/5 bg-[#FAFAFA]">
        <div className="mx-auto max-w-7xl px-6 py-14 md:px-8 md:py-20">
          <DemoGallery items={demoContent.gallery} />
        </div>
      </section>
    </main>
  );
}
