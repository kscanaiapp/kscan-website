export const demoContent = {
  video: {
    src: "/demo/kscan-demo.mp4",
    poster: "/demo/kscan-demo-poster.jpg",
    caption:
      "Current demo cut for K Scan AI. This version is optimized for silent autoplay across mobile, tablet, and desktop. Speech and richer scene variants can be added in the next pass.",
  },
  gallery: [
    {
      src: "/demo/scene-style-parse.jpg",
      title: "Style-Parse in context",
      description:
        "A still focused on the fashion-intelligence layer: silhouette, texture, color, and category.",
      tag: "Parse",
    },
    {
      src: "/demo/scene-ar-buy.jpg",
      title: "POV commerce moment",
      description:
        "A strong real-world scan moment that makes the product feel immediate, wearable, and transactional.",
      tag: "Wearable",
    },
    {
      src: "/demo/scene-checkout.jpg",
      title: "Checkout-ready flow",
      description:
        "A supporting still that proves K Scan is not just recognition — it closes the gap to purchase.",
      tag: "Conversion",
    },
  ],
};
